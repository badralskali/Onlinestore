<!DOCTYPE html>
        <?php 
        session_start();
        $h=$_SESSION['varname'];
       
        $servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";
	


        $a="aa";
        
        
        if ($a="aa") {
            
            $hh="Styles/Stylesheet_1.css";
        }
        
        ///////////////////////////////////////////////////////////////
        
        ?>
      <?php 

///////////////////////////// 1 //////////////////////////////////////////////////
 if (isset($_POST['Create'])) {
        
//************************************//

  $id=date("m/d")."-".date("h:m").":".$h.":".$_POST["Id"];
 
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO c1 (a)
VALUES ('".$id."')";

if ($conn->query($sql) === TRUE) {

  $id="";
 
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}
session_start();

/////////////////////////////////2/////////////////////////////////////////////////////
 
/////////////////////////////////3/////////////////////////////////////////////////////

/////////////////////////////////4/////////////////////////////////////////////////////
 
?>

<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="Styles/Stylesheet_3.css"/>
        
        <title><?php echo $title; ?></title>
        

        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?>/>
                
    </head>
    <body>

        <div id="wrapper" >
            <div id="banner">    
                <br>
                <br>
        <label style="color:white ;font-size: 40px; font-family: URW Chancery L;"> Trip guide to libya</label>
       <br>
        <label style="color:white ;font-size: 20px; font-family: URW Chancery L;"> <?php if ($h<>"")echo "welcom "."".$h; ?> </label>

            </div>
        <marquee style="font-size: 18px; color: red;">Cyrene, the ancient Greek city (in present-day Libya) was the oldest and most important of the five Greek cities in the region and gave eastern Libya the classical name 'Cyrenaica' that it has retained to modern times. It lies in a lush valley in the Jebel Akhdar uplands. It was named after a spring, Kyre, which the Greeks consecrated to Apollo. Cyrene was founded as a colony of the Greeks of Thera, traditionally led by Aristotle (later called Battus) of Thera, about 630 BC, ten miles from its port, Apollonia (Marsa Sousa). Details concerning the founding of the city are contained in Book IV of the Histories of Herodotus. It promptly became the chief town of the ancient Libyan region between Egypt and Carthage (Cyrenaica), kept up commercial relations with all the Greek cities, and reached the height of its prosperity under its own kings in the 5th century BC. Soon after 460 BC it became a republic; after the death of Alexander the Great (323 BC) it passed to the Ptolemies and fell into decay. Cyrenaica became part of the empire controlled by the Ptolemaic dynasty from Alexandria in Egypt and later passed to the Roman empire. Cyrene was the birthplace of Eratosthenes and there are a number of philosophers associated with the city including Callimachus, Carneades, Aristippus and Arete, and Synesius, bishop of Ptolemais in the 4th century CE. The inhabitants of Cyrene at the time of Sulla (c. 85 BC) were divided into four classes: citizens, farmers, resident aliens, and Jews, who formed a restless minority. Lucullus was sent to Cyrene by Sulla to quell disturbances in which the Jews were taking a prominent part. The ruler of the town, Apion bequeathed it to the Romans, but it kept its self-government. In 74 BC Cyrene was created a Roman province; but, whereas under the Ptolemies the Jewish inhabitants had enjoyed equal rights, they now considered themselves oppressed by the autonomous Greek population. Cultural conflicts were exacerbated by the resurgence of Jewish nationalism and resentment of Hellenistic culture with which many Jews had accommodated. Tensions came to a head in the insurrection of the Jews of Cyrene under Vespasian (AD 73) and especially Trajan (AD 117). This revolt was quelled by Marcius Turbo, but not before about 200,000 Romans and Greeks had been killed (Dio Cassius, lxviii. 32). By this outbreak Libya was depopulated to such an extent that a few years later new colonies had to be established there, according to Eusebius. Cyrene's chief local export through much of its early history -- the medicinal herb silphium -- was pictured on most Cyrenian coins, until it was harvested to extinction. Though commercial competition from Carthage and Alexandria reduced its trade, Cyrene, with its port of Apollonia (Marsa Susa), remained an important urban center until the earthquake of 365. Ammianus Marcellinus described it in the 4th century as a deserted city, and Synesius, a native of Cyrene, described it in the following century as a vast ruin at the mercy of the nomads. The names of six christian bishops are known: according to Byzantine legend the first was St. Lucius (Acts 13:1); St. Theodorus suffered martyrdom under Diocletian; about 370 Philo dared to consecrate by himself a bishop for Hydra, and was succeeded by his own nephew, Philo; Rufus sided with Dioscorus at the so-called Robber Synod (Latrocinium) of Ephesus in 449; Leontius lived about 600.   </marquee>

            <nav id="navigation">

                <ul id="nav">
                    <li><a  > </a></li>
                    <li><a  > </a></li>
                    <li><a  ></a></li>
                    <li><a  > </a></li>
                    <li><a  > </a></li>
                    <li><a  > </a></li>
                    <li><a href="index.php" style="background-color:  #4CAF50;" style=" text-align:  center;">Back</a></li>
          
            
                </ul>
             </nav>
   
 
             <div id="content_area" method="post" >
                             <label color="red">ITEMS</label>

         <form class="d">
 
          <p>

              
          </p>
         </form>
 
                <form method="post" >
		
                    
                <div class="input-group">
                    <label style="color: blue "> Previous comments : </label>
                    <br>
                    <?php
                   //////////////////////////////////////////////////////
                            /*********************************/    
                           // Create connection
                          $conn = new mysqli($servername, $username, $password, $dbname);
                         // Check connection
                          if ($conn->connect_error) {
                          die("Connection failed: " . $conn->connect_error);
                           }

                            $sql = "SELECT *  FROM c1 ";
                             $result = $conn->query($sql);

                              if ($result->num_rows > 0) {
   
                             // output data of each row
                            $i=0;
                             while($row = $result->fetch_assoc()) {
                            $comments[i]= $row["a"];
                              echo "-----------------------------------------------------------------------------------------------------------------------------------";
                          ?>
                    
                    <label style="background-color: wheat"  >  <?php echo $row["a"]; ?> </label>
                    
                        <?php
                              echo "<br>";
                             }
   
                             } else {
                             echo " No comments";
                             }
                            $conn->close();
  
                  ///////////////////////////////////////////////////////  
                                                            
                   ?>                                          
<label  >-------------------------------------------------------------------------------------------------------------------------------------</label>
		

		</div>  
                    
                <div class="input-group">
			<label>Add new -comment</label>
			<input type="text" name="Id" value="">
                      
		</div>

		<div class="input-group">
			<button class="btn" type="submit" name="Create" >Add </button>
		</div>
	       </form>
<label  >-------------------------------------------------------------------------------------------------------------------------------------</label>
              
                 
   
    
          
            <a href="rec.php" style="background-color:  #4CAF50;margin-left:5px; font-size: 13px" text-align="center">Request-To-administrator</a>

             </div>
                     
            <footer>
                <p style="margin-left:450px">All rights reserved</p>
            </footer>
        </div>
    </body>
</html>


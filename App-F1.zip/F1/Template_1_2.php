<!DOCTYPE html>

   <?php

    session_destroy();
   session_start();
  
   $l="Login";
   $xx="Guest";
   $color="#e9e9e9";
   $t="n";
   $hi="block";
$myVariable1="a";
$myVariable2="a";
    $conn = mysqli_connect("localhost","root","Bader2003","onlinestore");
    
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
      
    ?>

<?php
    	if(isset($_POST['login'])){
            
              
            
            if ($l=="Login" && $t=="n"){
                            

    		include('conn.php');
     
    		$username=$_POST['username'];
    		$password=$_POST['password'];
     
    		$query=mysqli_query($conn,"select * from `user` where username='$username' && password='$password'");
                     

    		if (mysqli_num_rows($query) == 0){
    			$_SESSION['message']="Login Failed. User not Found!";
    			
    		}
    		else{
    			$row=mysqli_fetch_array($query);
     
    			if (isset($_POST['remember'])){
    				//set up cookie
    				setcookie("users", $row['username'], time() + (86400 * 30)); 
    				setcookie("pass", $row['password'], time() + (86400 * 30)); 
    			}
                  

    			$_SESSION['id']=$row['username'];
    			
                          	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
    		 
    		exit();
    	}
                       

    	$query=mysqli_query($conn,"select * from user where username='".$_SESSION['id']."'");
    	$row=mysqli_fetch_assoc($query);
        $m= "welcom:".$row['fullname']; 
        $xx=$row['fullname'];
        session_start();
        $_SESSION['varname'] = $row['username'];
        $color=$row['coloruser'];
        $l="Logout";
         $t="n";
       
    		}
    	}
        
        
        if($l=="Logout" && $t=="g"){
            
            	session_start();
         	session_destroy();
     
    	       if (isset($_COOKIE["user"]) AND isset($_COOKIE["pass"])){
    		setcookie("user", '', time() - (3600));
    		setcookie("pass", '', time() - (3600));
    	          }
            
             $l="Login";
             $m="Wellcom:Gust";
             $t="n";
       
             }
             
        if ($l=="Logout" && $t=="n"){
            $t="g"; 
        }     
             
   
           
        }
    
    ?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title;
        
        
         
        ?></title>
        <?php 
                
         if ( $xx=="Badr Alsakali"){
             $hh="Styles/Stylesheet_2.css";
              
             $hi="none";
            
         }
 else {$hh="Styles/Stylesheet.css";}
        ?>
         
        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?> />
            <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="static/css/all.css">
    <link rel="stylesheet" href="static/css/top.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="static/js/bootstrap.min.js"></script>
        
        
    </head>
    <body  style="background-color:<?php echo $color ?>" >
        
        <div id="wrapper">
                       <div id="banner">  
                <br>
                <br>
                <label style="color:white ;font-size: 40px; font-family: URW Chancery L;"> Online-shopping</label>
            </div>

<div id="content_area" >  
   
<div class="gallery1">
    
  <a target="_blank1" href="index_1_1.php" onclick=<?php $myVariable1 = "p11.jpeg"; $_SESSION['varname1'] = $myVariable1;?>>
      <img src="./Img/p11.jpeg" alt="Cinque Terre1" width="600" height="400">
  </a>
    <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
  
</div>
    
 <div class="gallery">
  <a target="_blank2" href="index_1_1.php" onclick=<?php $myVariable2 = "p113.png"; $_SESSION['varname2'] = $myVariable2;?> >
      <img src="./Img/p113.png" alt="Cinque Terre2" width="600" height="400">
  </a>


  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>  

 <div class="gallery">
  <a target="_blank3" href="index_1_1.php" >
      <img src="./Img/p115.png" alt="Cinque Terre3" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>  
      
  <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p10.jpeg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>    
   
 <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p20.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
    
  <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p29.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>  
<div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p21.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>  
    <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p22.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>  
    
 <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p23.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
    
     <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p24.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
 <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p26.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
     <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p27.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    
<div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p30.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
    
    <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p13.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
  <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p40.jpeg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
 <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p41.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
     <div class="gallery">
         <a target="_blank" href="index_1_1.php">
      <img src="./Img/p43.jpeg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
  
     <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/113.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div> 
    
        <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p45.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
        <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p46.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    
 <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p47.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p50.jpeg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    
        <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p51.jpg" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    
        <div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
      <img src="./Img/p52.png" alt="Cinque Terre" width="600" height="400">
  </a>
  <div class="desc">Price : 30$</div>
  <div class="desc">Add </div>
</div>
    
</div>         
             
             
             
             
             
            
            
            <div id="sidebar" style="background-color: appworkspace ; height: 1478px;">
                  
            <a href="index.php" > Back to main page </a>            

                
            <div id="a" class="modal" style="background-color:  #1fb684 ">
  
            <form  method="post" class="modal-content animate">
           
            <div class="imgcontainer">
           
             <span onclick="document.getElementById('a').style.display='none'" class="close" title="Close Modal">&times;</span>
           
             <img src="Img/t3.jpg" alt="c" class="avatar">
            <br>
            <libel> <?php if($l=="Logout")echo 'see you soon' ?> </label>
            
            </div>



            <div class="container" style="background-color:#f1f1f1">
         
             </div>
             </form>
             </div>
            
          
            
              <label>-----------------------------</label>
              <img src="./Img/t1.jpg" style="width:100%" height="155px">
               <label>-----------------------------</label>
              <img src="./Img/t2.jpg" style="width:100%" height="155px">

              <label>-----------------------------</label>
              <img src="./Img/t9.jpg" style="width:100%" height="150px">
              <label>-----------------------------</label>
              <img src="./Img/t5.png" style="width:100%" height="150px">

              <label>-----------------------------</label>
              <img src="./Img/t6.png" style="width:100%" height="150px">
              <label>-----------------------------</label>
              <img src="./Img/t7.jpg" style="width:100%" height="150px">
               <label>-----------------------------</label>
               <img src="./Img/t8.png" style="width:100%" height="150px">
                              <label>-----------------------------</label>

                              <img src="./Img/t10.jpg" style="width:100%" height="125px">

               <br>
               <br>
      
       
            </div>

            
            <footer >
                <p style="margin-left:550px">All rights reserved</p>
            </footer>
        </div>
        
    </body>
</html>

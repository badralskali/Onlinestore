<!DOCTYPE html>
 



<link rel="stylesheet" type="text/css" href="Styles/style.css">
<html>
<head>
	<title></title>
</head>
<body id="dc" style="">

 <?php 
          

$servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";



 if (isset($_POST['Create'])) {
            
          
//************************************//

  $nusername=$_POST["nusername"];
  $npassword=$_POST["npassword"];
  $fullname=$_POST["fullname"];
  $coloruser=$_POST["coloruser"];
  $kind=$_POST["kind"];
  $email=$_POST["email"];  
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user (username, password, fullname,coloruser,kind,email)
VALUES ('".$nusername."','".$npassword."','".$fullname."','".$coloruser."','".$kind."','".$email."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
    echo "<script type='text/javascript'>alert('$message');</script>";

    
  $nusername="";
  $npassword="";
  $fullname="";
  $coloruser="";
  $kind="";
  $email="";
  
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}
        
 if (isset($_POST['Reserch'])) {
            
          
//************************************//

  $id=$_POST["Id"];
  $frname=$_POST["Firstname"];
  $Lastname=$_POST["Lastname"];
  $phone=$_POST["phone"];
  $address=$_POST["address"];
    
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT *  FROM t1 where a='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   
    // output data of each row
    while($row = $result->fetch_assoc()) {
    $id=$row["a"];
       $frname=$row["b"];
          $Lastname=$row["c"];
             $phone=$row["d"];
                $address=$row["e"];

    }
   
} else {
    echo "0 results";
}
$conn->close();
	
}
/********************************************************************/

 if (isset($_POST['Ubdate'])) {
            
          
//************************************//

  $id=$_POST["Id"];
  $frname=$_POST["Firstname"];
  $Lastname=$_POST["Lastname"];
  $phone=$_POST["phone"];
  $address=$_POST["address"];
    
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "UPDATE t1 SET  b='".$frname."',c='".$Lastname."',d='".$phone."',e='".$address."'WHERE a=".$id;

if ($conn->query($sql) === TRUE) {
        $id="";
  $frname="";
  $Lastname="";
  $phone="";
  $address="";
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

$conn->close();
	
}




/************************ Delete ****************************************/

 if (isset($_POST['Delete'])) {
     
 $id=$_POST["Id"];   
 
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record

$sql = "DELETE FROM t1 WHERE a =".$id;

if (mysqli_query($conn, $sql)) {
/**    echo "Record deleted successfully";**/
  $id="";
  $frname="";
  $Lastname="";
  $phone="";
  $address="";
} else {
   /** echo "Error deleting record: " . mysqli_error($conn);**/
}

mysqli_close($conn);
 }

/*************************************************************************/
  if (isset($_POST['Clear'])) {
  $id="";
  $frname="";
  $Lastname="";
  $phone="";
  $address="";

 }
 
 /*************************************************************************/
?>       

    <form method="post" action="newuser.php" style="background-color: inactivecaption" >
		<div class="input-group">
			<label>Username</label>
			<input type="text" name="nusername" value="<?php echo $nusername;?>">
                      
		</div>
		<div class="input-group">
			<label>Password</label>
                        <input type="text" name="npassword" value="<?php echo $npassword;?>">
		</div>
                <div class="input-group">
			<label>Fullname</label>
			<input type="text" name="fullname" value="<?php echo $fullname;?>">
		</div>
                <label class="d">Backcolor >> </label>
                
                <select class="opt" name="coloruser" value= "" </option>>
                               <option><?php if ($item1=="") echo White; if ($item1!="") echo White;?></option>
                               <option>Red</option>
                               <option>Green</option>
                               <option>blue</option>
                               <option>orange</option>
                               <option>gold</option>
                               <option>magenta</option>
                               <option>peru</option>
                               <option>darkslategray</option>
                                
                 </select>
                <br>
                 <label class="d">Kind of pages </label>
                 <select class="opt" name="kind" value= "" </option>>
                               <option><?php if ($item1=="") echo 'Private'; if ($item1!="") echo 'Private';?></option>
                               <option>Public</option>
                
                               
                 </select>
            
            
                <div class="input-group">
			<label>Email</label>
			<input type="text" name="email" value="<?php echo $kind;?>">
		</div>

   
      
            
		<div class="input-group">
			<button class="btn" type="submit" name="Create"  >Create</button>
                     
                        <button class="btnc" type="submit" name="Clear" >Clear</button>
                        
                                  <a href="index.php" style="background-color:  #4CAF50; font-size: 18px" text-align="center">Back to main Screen</a>

		</div>
	</form>
</body>


    
    
    



<!DOCTYPE html>

          <?php 
        session_start();
        $h=$_SESSION['varname'];
       
        $servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";
	


        $a="aa";
        
        
        if ($a="aa") {
            
            $hh="Styles/Stylesheet_1.css";
        }
        
        ///////////////////////////////////////////////////////////////
        
        ?>
      <?php 
            
    
///////////////////////////// 1 //////////////////////////////////////////////////
 if (isset($_POST['Create'])) {
        
//************************************//

  $id=date("m/d")."-".date("h:m").":".$h.":".$_POST["Id"];
 
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO c1 (a)
VALUES ('".$id."')";

if ($conn->query($sql) === TRUE) {

  $id="";
 
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}
session_start();

?>


<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title;
        
        
         
        ?></title>
        <?php 
                
         if ( $xx=="Badr Alsakali"){
             $hh="Styles/Stylesheet_2.css";
              
             $hi="none";
            
         }
 else {$hh="Styles/Stylesheet.css";}
        ?>
         
        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?> />
          
            <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="static/css/all.css">
    <link rel="stylesheet" href="static/css/top.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="static/js/bootstrap.min.js"></script>
        
        
    </head>
    <body  style="background-color:<?php echo $color ?>" >
        
        <div id="wrapper">

 <section id="s1" style=";  background-color:  buttonshadow">
 <div class="container" >
  <div class="row">
      <div class="col" >
   
          <h1 class="display-4" style=" font-size: 20px"  >Online-Shopping</h1>
    <p class="lead" style=" font-size: 15px"> The Internet has revolutionized the way we shop. Because of the numerous advantages and benefits, more and more people these days prefer buying things online over the conventional method of going into stores </p>
       
    </div>
 
    </div>
  </div>
  </section>
             
              <?php  
 $connect = mysqli_connect("localhost", "root", "Bader2003", "onlinestore");  
 if(isset($_POST["insert"]))  
 {  
 
       $tt1=$_POST["ntt1"];
       $tt2=$_POST["ntt2"];
       $tt3=$_POST["ntt3"];
       $tt4=$_POST["ntt4"];
     
      $file = addslashes(file_get_contents($_FILES["image"]["tmp_name"]));  
      $query = "INSERT INTO tbl_images(name,t1,t2,t3,t4) VALUES ('$file','$tt1','$tt2','$tt3','$tt4')";  
      if(mysqli_query($connect, $query))  
      {  
            
      }  
 }  
 ?>  
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>Webslesson Tutorial | Insert and Display Images From Mysql Database in PHP</title>  
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body>  
          <nav id="navigation">
                <ul id="nav1">
                    <li><a href="index.php"> Back </a></li>
                    <li><a href="index_1.php"> Items</a></li>
                    <li><a href="index.php"> check-out </a></li>
                    <li><a  href="newuser.php"  > Registration </a></li> 
             
                </ul>
            </nav>
           <br /><br />  
           <div class="container1" style="width:500px; background-color:  khaki">  
                <form method="post" enctype="multipart/form-data">  
                    
               <div class="input-group">
			<label>customer :</label>
			<input type="text" name="ntt1" value="<?php echo $ntt1;?>">
                      
		</div>
		<div class="input-group">
			<label>Emailuser:</label>
                        <input type="text" name="ntt2" value="<?php echo $ntt2;?>">
		</div>
                <div class="input-group">
			<label>Telephone</label>
			<input type="text" name="ntt3" value="<?php echo $ntt3;?>">
		</div>
                 <div class="input-group">
			<label>Description and Price </label>
			<input type="text" name="ntt4" value="<?php echo $ntt4;?>">
		</div>
                    
                    <br>
                     <input type="file" name="image" id="image" />  
                     <br />  
                     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />  
             
                
                
                
                </form>  
                <br />  
                <br />  
                <table class="table table-bordered">  
                     <tr>  
                          <th>Image</th>  
                     </tr>  
                <?php  
                $query = "SELECT * FROM tbl_images ORDER BY id DESC";  
                $result = mysqli_query($connect, $query);  
                while($row = mysqli_fetch_array($result))  
                {  
                     echo '  
                          <tr>  
                               <td> 
                                     <label>customer :</label>'.$row['t1'] .'<br>
                                     <label>Emailuser:</label>'.$row['t2'] .'<br>
                                     <label>Telephone</label>'.$row['t3'] .'<br>
                                     <label>Description and Price </label>'.$row['t4'] .'<br>
                                    <img src="data:image/jpeg;base64,'.base64_encode($row['name'] ).'" height="250" width="250" class="img-thumnail" />  
                               </td>  
                          </tr>  
                     ';  
                }  
                ?>  
                </table>  
           </div>  
      </body>  
 </html>  
 <script>  
 $(document).ready(function(){  
      $('#insert').click(function(){  
           var image_name = $('#image').val();  
           if(image_name == '')  
           {  
                alert("Please Select Image");  
                return false;  
           }  
           else  
           {  
                var extension = $('#image').val().split('.').pop().toLowerCase();  
                if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)  
                {  
                     alert('Invalid Image File');  
                     $('#image').val('');  
                     return false;  
                }  
           }  
      });  
 });  
 </script>  
             
             
   
             
 
   
            <div id="sidebar120" style="background-color: appworkspace ; height: 3830px;">
    
             <div id="content_area101" method="post" style=" background-color: buttonshadow;width: 700px;">

                 <form method="post" >
		
                    
                    <div class="input-group">
                    <label style="color: blue "> Previous comments : </label>
                    <br>
                    <?php
                   //////////////////////////////////////////////////////
                            /*********************************/    
                           // Create connection
                          $conn = new mysqli($servername, $username, $password, $dbname);
                         // Check connection
                          if ($conn->connect_error) {
                          die("Connection failed: " . $conn->connect_error);
                           }

                            $sql = "SELECT *  FROM c1 ";
                             $result = $conn->query($sql);

                              if ($result->num_rows > 0) {
   
                             // output data of each row
                            $i=0;
                             while($row = $result->fetch_assoc()) {
                            $comments[i]= $row["a"];
                            ?>
                                    <?php
                          ?>
                    
                    <label style="background-color: #E3E3E3"  >  <?php echo $row["a"]; ?> </label>
                    
                        <?php
                              echo "<br>";
                             }
   
                             } else {
                             echo " No comments";
                             }
                            $conn->close();
  
                  ///////////////////////////////////////////////////////  
                                                            
                   ?>                                          
<label  >-------------------------------------------------------------------------------------------------------------------------------------</label>
		

		</div>  
                    
                <div class="input-group">
                    <label style=" color:  #f44336"> Add new -comment</label>
			<input type="text" name="Id" value="">
                      
		</div>

		<div class="input-group">
                      
                        <input type="submit" name="Create" value="Add" />
                         
		</div>
	       </form>
     
     
</div>


            </div>
               <footer >
                <p style="margin-left:550px">All rights reserved</p>
            </footer>
        </div>
        
    </body>
</html>

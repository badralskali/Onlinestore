<!DOCTYPE html>

   <?php
   
   $l="Login";
   $m="Wellcom:Guest";
   $t="n";
   $hi="block";
    session_start();
    $conn = mysqli_connect("localhost","root","123456","cookie");
    
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
      
    ?>

<?php
    	if(isset($_POST['login'])){
            
            if ($l=="Login" && $t=="n"){
                session_start();
    		include('conn.php');
     
    		$username=$_POST['username'];
    		$password=$_POST['password'];
     
    		$query=mysqli_query($conn,"select * from `user` where username='$username' && password='$password'");
     
    		if (mysqli_num_rows($query) == 0){
    			$_SESSION['message']="Login Failed. User not Found!";
    			
    		}
    		else{
    			$row=mysqli_fetch_array($query);
     
    			if (isset($_POST['remember'])){
    				//set up cookie
    				setcookie("user", $row['username'], time() + (86400 * 30)); 
    				setcookie("pass", $row['password'], time() + (86400 * 30)); 
    			}
     
    			$_SESSION['id']=$row['userid'];
    			
                          	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
    		 
    		exit();
    	}
    	$query=mysqli_query($conn,"select * from user where userid='".$_SESSION['id']."'");
    	$row=mysqli_fetch_assoc($query);
        $m= "welcom:".$row['fullname']; 
        $xx=$row['fullname']; 
        $l="Logout";
         $t="n";
       
    		}
    	}
        
        
        if($l=="Logout" && $t=="g"){
            
            	session_start();
         	session_destroy();
     
    	       if (isset($_COOKIE["user"]) AND isset($_COOKIE["pass"])){
    		setcookie("user", '', time() - (3600));
    		setcookie("pass", '', time() - (3600));
    	          }
            
             $l="Login";
             $m="Wellcom:Gust";
             $t="n";
       
             }
             
        if ($l=="Logout" && $t=="n"){
            $t="g"; 
        }     
             
   
           
        }
    
    ?>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title;
        
        
         
        ?></title>
        <?php 
                
         if ( $xx=="Badr Alsakali"){
             $hh="Styles/Stylesheet_1.css";
              
             $hi="none";
            
         }
 else {$hh="Styles/Stylesheet.css";}
        ?>
         
        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?> />
    </head>
    <body>
        
        <div id="wrapper">
            <div id="banner">             
            </div>
             <br>
            <nav id="navigation">
      
            </nav>
              
            <div id="content_area">
               
                <?php echo $content; ?>
            </div>
            
            <div id="sidebar">
                  
             

                
                <div id="a" class="modal">
  
            <form  method="post" class="modal-content animate">
           
            <div class="imgcontainer">
           
           
            <img src="Images/coffee1.png" alt="c" class="avatar">
            
            </div>

            <div class="container">
                
            <label for="uname"><b>Username</b></label>
            <input type="text" value="<?php if (isset($_COOKIE["user"])){echo $_COOKIE["user"];}?>" name="username">
            <label for="psw"><b>Password</b></label>
            <label>Password:</label> <input type="password" value="<?php if (isset($_COOKIE["pass"])){echo $_COOKIE["pass"];}?>" name="password"><br><br>
            <input type="submit" value="Login" name="login">

            <label>
            <input type="checkbox" checked="checked" name="remember"> Remember me
            </label>
            </div>

            <div class="container" style="background-color:#f1f1f1">
         
             </div>
             </form>
             </div>
            
            <input style = "width: 200px;" type="text" name="b" value=<?php echo $m ?> />
            
            </div>
            <div id="sidebar">
                
            </div>
            
            <footer>
                <p style="margin-left:450px">All rights reserved</p>
            </footer>
        </div>
    </body>
</html>

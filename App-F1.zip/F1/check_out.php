<!DOCTYPE html>
 



<link rel="stylesheet" type="text/css" href="Styles/Stylesheet_4.css">
<html>
<head>
	<title>OnlineStore</title>
</head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
th, td {
  padding: 5px;
  text-align: left;
}
</style>
<body>

 <?php 
          

$servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";
	


 if (isset($_POST['Create'])) {
            
          
//************************************//

  $id=$_POST["id"];
  $name_customer=$_POST["name_customer"];
  $da_customer=$_POST["da_customer"];
  $item1=$_POST["item1"];
  $item2=$_POST["item2"];
  $item3=$_POST["item3"];
  $total=$_POST["total"];
  $id_passport=$_POST["id_passport"];
  $id_license=$_POST["id_license"];
  $Address1=$_POST["Address1"];
  $Address2=$_POST["Address2"];
  $Email1=$_POST["Email1"];
  $Email2=$_POST["Email2"];
  $phone1=$_POST["phone1"];
  $phone2=$_POST["phone2"];
  
 
    
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO Customers_data (id, name_customer, da_customer,item1,item2,item3,total,id_passport,id_license,Address1,Address2,Email1,Email2,phone1,phone2)
VALUES ('".$id."','".$name_customer."','".$da_customer."','".$item1."','".$item2."','".$item3."','".$total."','".$id_passport."','".$id_license."','".$Address1."','".$Address2."','".$Email1."','".$Email2."','".$phone1."','".$phone2."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
    echo "<script type='text/javascript'>alert('$message');</script>";

    
  $id="";
  $name_customer="";
  $da_customer="";
  $item1="";
  $item2="";
  $item3="";
  $total="";
  $id_passport="";
  $id_license="";
  $Address1="";
  $Address2="";
  $Email1="";
  $Email2="";
  $phone1="";
  $phone2="";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}
        

/********************************************************************/

 if (isset($_POST['UPdate'])) {
            
          
//************************************//
  $id=$_POST["id"];
  $name_customer=$_POST["name_customer"];
  $da_customer=$_POST["da_customer"];
  $item1=$_POST["item1"];
  $item2=$_POST["item2"];
  $item3=$_POST["item3"];
  $total=$_POST["total"];
  $id_passport=$_POST["id_passport"];
  $id_license=$_POST["id_license"];
  $Address1=$_POST["Address1"];
  $Address2=$_POST["Address2"];
  $Email1=$_POST["Email1"];
  $Email2=$_POST["Email2"];
  $phone1=$_POST["phone1"];
  $phone2=$_POST["phone2"];
    
       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$sql = "UPDATE Customers_data SET  name_customer='".$name_customer."',da_customer='".$da_customer."',item1='".$item1."',item2='".$item2."',item3='".$item3."',total='".$total."',id_passport='".$id_passport."',id_license='".$id_license."',Address1='".$Address1."',Address2='".$Address2."',Email1='".$Email1."',Email2='".$Email2."',phone1='".$phone1."',phone2='".$phone2."' WHERE id=".$id;

if ($conn->query($sql) === TRUE) {
  $id="";
  $name_customer="";
  $da_customer="";
  $item1="";
  $item2="";
  $item3="";
  $total="";
  $id_passport="";
  $id_license="";
  $Address1="";
  $Address2="";
  $Email1="";
  $Email2="";
  $phone1="";
  $phone2="";
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
    echo $sql;
}

$conn->close();
	
}




/************************ Delete ****************************************/

 if (isset($_POST['Delete'])) {
     
 $id=$_POST["id"];   
 
// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// sql to delete a record

$sql = "DELETE FROM Customers_data WHERE id=".$id;

if (mysqli_query($conn, $sql)) {
/**    echo "Record deleted successfully";**/
  $id="";
  $name_customer="";
  $da_customer="";
  $item1="";
  $item2="";
  $item3="";
  $id_passport="";
  $id_license="";
  $Address1="";
  $Address2="";
  $Email1="";
  $Email2="";
  $phone1="";
  $phone2="";
} else {
   /** echo "Error deleting record: " . mysqli_error($conn);**/
}

mysqli_close($conn);
 }

/*************************************************************************/
  if (isset($_POST['Clear'])) {
  $id="";
  $name_customer="";
  $da_customer="";
  $item1="";
  $item2="";
  $item3="";
  $id_passport="";
  $id_license="";
  $Address1="";
  $Address2="";
  $Email1="";
  $Email2="";
  $phone1="";
  $phone2="";

 }
 
 /*************************************************************************/
 

 /*************************************************************************/
?>       
 
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title;
        
        
         
        ?></title>
        <?php 
                
         if ( $xx=="Badr Alsakali"){
             $hh="Styles/Stylesheet_2.css";
              
             $hi="none";
            
         }
 else {$hh="Styles/Stylesheet_1.css";}
        ?>
         
        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?> />
            <!-- Bootstrap CSS -->
  

         <link rel="stylesheet" type="text/css" href="Styles/Stylesheet_4.css">     
  
        
    </head>
    <body  style="background-color:<?php echo $color ?>" >
        
        <div id="wrapper">
            <div id="banner">  
                <br>
                <br>
                <label style="color:white ;font-size: 40px; font-family: URW Chancery L;"> Online-shopping</label>
            </div>
            <marquee style="font-family: FreeSerif;font-size: 20px; color:  #800000;"><img src="./Images/reg.png" style="width:20%" height="20px"> - Wellcom :<?php echo $xx ; echo " : Today is " . date("Y/m/d") ."";echo "  : The time is " . date("h:i:sa"); ?> </marquee>
             <br>
    
            <nav id="navigation">
                <ul id="nav1">
                    <li><a href="index.php"> Back </a></li>
             
                </ul>
            </nav>

             <form method="post" action="check_out.php" >
		<div class="input-group">
			<label class="d">YourName</label>
			<input type="text" name="id" value="<?php echo $id;?>">
                      
		</div>
		
        
		<div class="input-group">
			
                        <button class="btn" type="submit" name="Read" >Show-Receipt</button>
		</div>
           <?php   
                   
 if (isset($_POST['Read'])) {
            
          
//************************************//
  $id=$_POST["id"];
  $nameid=$id;     
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT *  FROM user1 where username='$id'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
   
    // output data of each row
    ?>   
  <table style="width:100%">
  <caption>Receipt - customer(  <?php echo $id;  ?>   )</caption>
  </table>
      <?php 
    while($row = $result->fetch_assoc()) {
                
  $id=$row["username"];
  $name_customer=$row["password"];
  $da_customer=$row["fullname"];
  $item1=$row["item"];
  $item2=$row["pric"];
  ?>
<table style="width:100%">
  <tr>
    <td><?php echo $id ;?></td>
    <td><?php echo $name_customer;?></td>
    <td><?php echo $da_customer;?></td>
    <td><?php echo  $item1;?></td>
    <td><?php echo  $item2;?></td>
    <?php $c=$c+$item2;?>
    
  </tr>
 </table> 
  <?php
    }
    ?>
                 <br>
     <table style="width:100%">
  <caption>Total >> Receipt - customer(<?php echo $id;  ?> )=(  <?php echo $c;  ?>   )</caption>
  

     </table> 
          
   <br>              
   <hr>              
                 

<div class="input-group">
                <label>Please complete the form for  confirm the buy</label>
                <hr>
		<label>ID-customer</label>
                <br>
		<input type="text" name="n1" value="<?php echo $n1;?>">
                      
		</div>
		<div class="input-group">
			<label>Full-Name:</label>
                        <br>
                        <input type="text" name="n2" value="<?php echo $n2;?>">
		</div>
                <div class="input-group">
			<label>Email</label>
                        <br>
			<input type="text" name="n3" value="<?php echo $n3;?>">
		</div>
                   <div class="input-group">
			<label>Address</label>
                        <br>
			<input type="text" name="n4" value="<?php echo $n4;?>">
		</div>
                   <div class="input-group">
			<label>Phone</label>
                        <br>
			<input type="text" name="n5" value="<?php echo $n5;?>">
		</div>
                <br>
                <label > Buy >>financial-check/Cash/Online </label>
                <div class="input-group">
			
                           
			<input type="text" name="n6" value="<?php echo $n6;?>">
		</div>
                <br>     
<div class="input-group">
 <button class="btn" type="submit" name="ss" >BYU</button>
</div>
 
                 
                 
                 
             
                 
                 <?php
} else {
    echo "";
}
$conn->close();
	
}
/********************************************************************/
           
           ?>
   
	</form>
  
  
    <?php 
$servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";

  if (isset($_POST['ss'])) {
      
          
//************************************//
  $n11=$_POST["n1"];
  $n22=$_POST["n2"];
  $n33=$_POST["n3"];
  $n44=$_POST["n4"];
  $n55=$_POST["n5"];
  $n66=$_POST["n6"];
        
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$sql = "INSERT INTO userf (n1, n2, n3,n4,n5,item11)
VALUES ('".$n11."','".$n22."','".$n33."','".$n44."','".$n55."','".$n66."')";

if ($conn->query($sql) === TRUE) {

  $message = "Thank You Dear: [ ".$n22." ] We will send to you Email for your order by your Email [ ".$n33." ] ";
  
    echo "<script type='text/javascript'>alert('$message');</script>";

    
  $id="";
  $name_customer="";
  $da_customer="";
  $item1="";
  $item2="";
  $item3="";
  $total="";
  $id_passport="";
  $id_license="";
  $Address1="";
  $Address2="";
  $Email1="";
  $Email2="";
  $phone1="";
  $phone2="";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}

?>          
 
</body>

<html>

   
    
    





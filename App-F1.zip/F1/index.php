<?php
$title = "Home";
$content1 = '

     ' ;  
$content2 = '
   
         ';
$content3 = ' 

';
$content4 = '
';
include 'Template.php';
?>

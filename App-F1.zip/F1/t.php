<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        
   
        
        
        
        <?php

       

$content1 = '
        <h3> Greek period </h3>
        <p>
       
The Temple of Zeus, Cyrene According to Greek tradition, Cyrene was founded in 631 BC as a settlement of Greeks from the island of Thera, traditionally led by Battus I, at a site 16 kilometres (10 mi) from its associated port, 
Apollonia (Marsa Sousa). Traditional details concerning the founding of the city are contained in Herodotus Histories IV. Cyrene promptly became the chief town of ancient Libya and established commercial 
relations with all the Greek cities, reaching the height of 
its prosperity under its own kings in the 5th century BC. Soon after 460 BC it became a republic. In 413 BC, during the Peloponnesian War, Cyrene supplied Spartan forces with two triremes and pilots. 
After the death of Alexander the Great of Macedon 
         (323 BC), the Cyrenian republic became subject to the Ptolemaic dynasty. 
         </p>

     
<br>
<br>  
'
;$content2 = '    <h3>Roman period</h3>
        <p>


In 74 BC Cyrene was created a Roman province; but, whereas under the Ptolemies the Jewish inhabitants had enjoyed equal rights, they were allegedly increasingly oppressed by the now autonomous and much larger Greek population. Tensions came to a head in the insurrection of the Jews of Cyrene under Vespasian (73 AD, the First Jewish–Roman War) and especially Trajan (117 AD, the Kitos War). This revolt was quelled by Marcius Turbo, but not before huge numbers of civilians had been brutally massacred by the Jewish rebels.[9] According to Eusebius of Caesarea, the Jewish rebellion left Libya so depopulated to such an extent that a few years later new colonies had to be established there by the emperor Hadrian just to maintain the viability of continued settlement.

Plutarch in his work De mulierum virtutibus ("On the Virtues of Women") describes how the tyrant of Cyrene, Nicocrates, was deposed by his wife Aretaphila of Cyrene around the year 50 BC[10]

The famous "Venus of Cyrene", a headless marble statue representing the goddess Venus, a Roman copy of a Greek original, was discovered by Italian soldiers here in 1913. It was transported to Rome, where it remained until 2008, when it was returned to Libya.[11] A large number of Roman sculptures and inscriptions were excavated at Cyrene by Captain Robert Murdoch Smith and Commander Edwin A. Porcher during the mid nineteenth century and can now be seen in the British Museum.[12] They include the Apollo of Cyrene and a unique bronze head of an African man.[13][14]
         </p>

<br>
<br>
';$content3 = '
         <h3>Christianity</h3>
          <img src="Images/ss1.jpg" class="imgLeft" />
         <p>
Christianity is reputed from its beginning to have links with Cyrene. All three synoptic Gospels mention a Simon of Cyrene as having been forced to help carry the cross of Jesus. In the Acts of the Apostles there is mention of people from Cyrene being in Jerusalem on the day of Pentecost.According to the tradition of the Coptic Orthodox Church, its founder, Saint Mark was a native of Cyrene and ordained the first bishop of Cyrene. The Roman Martyrology mentions under 4 July a tradition that in the persecution of Diocletian a bishop Theodorus of Cyrene was scourged and had his tongue cut out. Earlier editions of the Martyrology mentioned what may be the same person also under 26 March. Letter 67 of Synesius tells of an irregular episcopal ordination carried out by a bishop Philo of Cyrene, which was condoned by Athanasius. The same letter mentions that a nephew of this Philo, who bore the same name, also became bishop of Cyrene. Although Cyrene was by then ruined, a bishop of Cyrene name Rufus was at the Robber Council of Ephesus in 449. And there was still a bishop of Cyrene, named Leontius, at the time of Greek Patriarch Eulogius of Alexandria .
       
         </p>
';
        include 'Template1.php';
        ?>
    </body>
    
</html>

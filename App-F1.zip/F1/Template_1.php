<!DOCTYPE html>

   <?php

    session_destroy();
   session_start();
  
   $l="Login";
   $xx="Guest";
   $color="#e9e9e9";
   $t="n";
   $hi="block";
$myVariable1="a";
$myVariable2="a";
    $conn = mysqli_connect("localhost","root","Bader2003","onlinestore");
    
    // Check connection
    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
      
    ?>

<?php

$servername = "localhost";
$username = "root";
$password = "Bader2003";
$dbname = "onlinestore";

 if (isset($_POST['Create1'])) {
            
          
//************************************//

  $nusername=$_POST["nusername"];
  $npassword=$_POST["npassword"];
  $fullname=$_POST["fullname"];
  $items='Bicycle';  
  $pric='300';
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user1 (username, password, fullname,item,pric )
VALUES ('".$nusername."','".$npassword."','".$fullname."','".$items."','".$pric."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
   
  $nusername="";
  $npassword="";
  $fullname="";
  
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}


 if (isset($_POST['Create2'])) {
            
          
//************************************//

  $nusername=$_POST["nusername"];
  $npassword=$_POST["npassword"];
  $fullname=$_POST["fullname"];
   $items='Lab-top';  
   $pric='700';
  
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user1 (username, password, fullname,item,pric )
VALUES ('".$nusername."','".$npassword."','".$fullname."','".$items."','".$pric."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
     
  $nusername="";
  $npassword="";
  $fullname="";
  
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}


 if (isset($_POST['Create3'])) {
            
          
//************************************//

  $nusername=$_POST["nusername"];
  $npassword=$_POST["npassword"];
  $fullname=$_POST["fullname"];
  $items='toy-330';  
  $pric='40';      
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user1 (username, password, fullname,item,pric )
VALUES ('".$nusername."','".$npassword."','".$fullname."','".$items."','".$pric."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
     
  $nusername="";
  $npassword="";
  $fullname="";
  
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}


 if (isset($_POST['Create4'])) {
            
          
//************************************//

  $nusername=$_POST["nusername"];
  $npassword=$_POST["npassword"];
  $fullname=$_POST["fullname"];
   $items='Sc-driv';  
  $pric='140';       
//*********************************//     
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO user1 (username, password, fullname,item,pric )
VALUES ('".$nusername."','".$npassword."','".$fullname."','".$items."','".$pric."')";

if ($conn->query($sql) === TRUE) {

  $message = "New record created successfully";
  
      
  $nusername="";
  $npassword="";
  $fullname="";
  
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
	
}


     	if(isset($_POST['login'])){
            
              
            
            if ($l=="Login" && $t=="n"){
                            

    		include('conn.php');
     
    		$username=$_POST['username'];
    		$password=$_POST['password'];
     
    		$query=mysqli_query($conn,"select * from `user` where username='$username' && password='$password'");
                     

    		if (mysqli_num_rows($query) == 0){
    			$_SESSION['message']="Login Failed. User not Found!";
    			
    		}
    		else{
    			$row=mysqli_fetch_array($query);
     
    			if (isset($_POST['remember'])){
    				//set up cookie
    				setcookie("users", $row['username'], time() + (86400 * 30)); 
    				setcookie("pass", $row['password'], time() + (86400 * 30)); 
    			}
                  

    			$_SESSION['id']=$row['username'];
    			
                          	if (!isset($_SESSION['id']) ||(trim ($_SESSION['id']) == '')) {
    		 
    		exit();
    	}
                       

    	$query=mysqli_query($conn,"select * from user where username='".$_SESSION['id']."'");
    	$row=mysqli_fetch_assoc($query);
        $m= "welcom:".$row['fullname']; 
        $xx=$row['fullname'];
        session_start();
        $_SESSION['varname'] = $row['username'];
        $color=$row['coloruser'];
        $l="Logout";
         $t="n";
       
    		}
    	}
        
        
        if($l=="Logout" && $t=="g"){
            
            	session_start();
         	session_destroy();
     
    	       if (isset($_COOKIE["user"]) AND isset($_COOKIE["pass"])){
    		setcookie("user", '', time() - (3600));
    		setcookie("pass", '', time() - (3600));
    	          }
            
             $l="Login";
             $m="Wellcom:Gust";
             $t="n";
       
             }
             
        if ($l=="Logout" && $t=="n"){
            $t="g"; 
        }     
             
   
           
        }
    
    ?>



<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title><?php echo $title;
        
        
         
        ?></title>
        <?php 
                
         if ( $xx=="Badr Alsakali"){
             $hh="Styles/Stylesheet_2.css";
              
             $hi="none";
            
         }
 else {$hh="Styles/Stylesheet.css";}
        ?>
         <link rel="stylesheet" type="text/css" href="Styles/style101.css">

        <link rel="stylesheet" type="text/css" href=<?php echo $hh ?> />
            <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="static/css/all.css">
    <link rel="stylesheet" href="static/css/top.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
<script src="static/js/bootstrap.min.js"></script>

        
        
    </head>
    <body  style="background-color:<?php echo $color ?>" >
        
        <div id="wrapper">
                       <div id="banner">  
                <br>
                <br>
                <label style="color:white ;font-size: 40px; font-family: URW Chancery L;"> Online-shopping</label>
              </div>
            <nav id="navigation">
                <ul id="nav1">
                    <li><a href="index.php"> Back </a></li>
                     <li><a href="index_1_re.php"> Upload-Items</a></li>
                    <li><a href="check_out.php"> check-out </a></li>
                    <li><a  href="newuser.php"  > Registration </a></li> 
           
                </ul>
            </nav>
            

<div id="content_area1" >  
 <img src="./Img/p11.jpeg" width="328px"  >
 <br>
 <br>
  <br>
 <hr>
 <img src="./Img/p113.png" width="328px"  >
  <br>
 <br>
 <hr>
 <img src="./Img/p50.jpeg" width="328px"  >
  <br>
 <br>
 <br>
 <br>
 <hr>
 <img src="./Img/p46.jpg" width="328px"  >
</div>

      
            <div id="sidebar1" style="background-color: appworkspace ; ">
               <label > [ Item : Bicycle ]</label> <label >[ Price:300$ ] </label> <label > [ Number:9A3325555A ]</label> 

                <form method="post" action="Template_1.php" style="background-color: inactivecaption" >
	   
                <div class="input-group">
			<label >Name</label>
			<input type="text" name="nusername" value="<?php echo $nusername;?>">
                      
		</div>
		<div class="input-group">
			<label> e-mail</label>
                        <input type="text" name="npassword" value="<?php echo $npassword;?>">
		</div>
                <div class="input-group">
			<label> Mobile</label>
			<input type="text" name="fullname" value="<?php echo $fullname;?>">
		</div>
     
		<div class="input-group">
			<button type="submit" name="Create1"  >Add ot cart</button>

		</div>
	</form>
           
            </div>
          
         <div id="sidebar1" style="background-color: appworkspace ; ">
               <label > [ Item : Laptop-HP ]</label> <label >[ Price:700$ ] </label> <label > [ Number:70025555A ]</label> 
                <form method="post" action="Template_1.php" style="background-color: inactivecaption" >
	   
                <div class="input-group">
			<label >Name</label>
			<input type="text" name="nusername" value="<?php echo $nusername;?>">
                      
		</div>
		<div class="input-group">
			<label> e-mail</label>
                        <input type="text" name="npassword" value="<?php echo $npassword;?>">
		</div>
                <div class="input-group">
			<label> Mobile</label>
			<input type="text" name="fullname" value="<?php echo $fullname;?>">
		</div>
     
		<div class="input-group">
			<button type="submit" name="Create2"  >Add ot cart</button>

		</div>
	        </form>
           
            </div>
                     <div id="sidebar1" style="background-color: appworkspace ; ">
               <label > [ Item : Toy-A500 ]</label> <label >[ Price:40$ ] </label> <label > [ Number:365225555A ]</label> 
                <form method="post" action="Template_1.php" style="background-color: inactivecaption" >
	   
                <div class="input-group">
			<label >Name</label>
			<input type="text" name="nusername" value="<?php echo $nusername;?>">
                      
		</div>
		<div class="input-group">
			<label> e-mail</label>
                        <input type="text" name="npassword" value="<?php echo $npassword;?>">
		</div>
                <div class="input-group">
			<label> Mobile</label>
			<input type="text" name="fullname" value="<?php echo $fullname;?>">
		</div>
     
		<div class="input-group">
			<button type="submit" name="Create3"  >Add ot cart</button>

		</div>
	        </form>
           
            </div>

                     <div id="sidebar1" style="background-color: appworkspace ; ">
               <label > [ Item : Sc-Driv ]</label> <label >[ Price:140$ ] </label> <label > [ Number:15425555A ]</label> 
                <form method="post" action="Template_1.php" style="background-color: inactivecaption" >
	   
                <div class="input-group">
			<label >Name</label>
			<input type="text" name="nusername" value="<?php echo $nusername;?>">
                      
		</div>
		<div class="input-group">
			<label> e-mail</label>
                        <input type="text" name="npassword" value="<?php echo $npassword;?>">
		</div>
                <div class="input-group">
			<label> Mobile</label>
			<input type="text" name="fullname" value="<?php echo $fullname;?>">
		</div>
     
		<div class="input-group">
			<button type="submit" name="Create4"  >Add ot cart</button>

		</div>
	        </form>
           
                 </div>

            
            <footer >
                <p style="margin-left:550px">All rights reserved</p>
            </footer>
        </div>
        
    </body>
</html>

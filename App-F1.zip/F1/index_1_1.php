<?php
$title = "Home";
$content1 = '
       
        <h3>CYRENAICA-Ancient</h3>
        <p>
         
        </p>
     ' ;  
$content2 = '
   
        <h3>TRIPOLI-Ancient</h3>
        <p>

         </p>
          <img src="Images/30.jpg" class="imgLeft" />
          <img src="Images/31.jpg" class="imgLeft" />
          <img src="Images/33.jpg" class="imgLeft" />
         ';
$content3 = ' 
    
        <h3>FEZZAN-Ancient</h3>
        <img src="Images/34.jpeg" class="imgLeft" />
        <p>

         </p>
';
$content4 = '
         <br>
         <h3>Hotels</h3>
         <p>
         </p>
                <img src="Images/35.jpeg" class="imgLeft" />
                <img src="Images/36.jpg" class="imgLeft" />
                <img src="Images/37.jpg" class="imgLeft" />
   
         </p>';
include 'Template_1_1.php';
?>
